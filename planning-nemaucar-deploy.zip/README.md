# Planning Nemaucar

Application web de gestion quotidienne pour les locations Nemaucar.

## Ce que fait cette version

- sauvegarde des donnees dans le site Netlify,
- connexion par mot de passe,
- deconnexion,
- sauvegarde persistante des vehicules, locations, clients et statuts,
- export et import JSON,
- interface responsive ordinateur et tablette.

## Important sur la securite

Le mot de passe est protege cote serveur via les fonctions Netlify.

Cette solution est adaptee a un petit usage interne avec un mot de passe partage.
Si plus tard tu veux plusieurs comptes utilisateurs, il faudra evoluer vers une vraie gestion d'utilisateurs.

## Mise en ligne sur Netlify

1. Deployer le dossier `planning-nemaucar` sur Netlify.
2. Dans Netlify, ouvrir `Site configuration`.
3. Aller dans `Environment variables`.
4. Ajouter ces 2 variables :

- `NEMAUCAR_APP_PASSWORD` : le mot de passe que tu veux utiliser
- `NEMAUCAR_SESSION_SECRET` : une phrase secrete longue et difficile a deviner

Exemple de secret :
`Nemaucar-Planning-Secret-2026-Change-Moi`

5. Relancer un deploy.

Ensuite, a l'ouverture du site, la page de connexion apparaitra automatiquement.

## Donnees reelles

Les anciennes donnees d'exemple ne sont plus imposees.

Tu peux maintenant :

1. te connecter,
2. cliquer sur `Ajouter un vehicule`,
3. saisir tes 4 vehicules reels,
4. ajouter ensuite tes vraies locations.

Si tu veux que je precharge directement tes 4 vehicules dans le code, envoie-moi pour chacun :

- immatriculation
- modele
- statut
- kilometrage
- notes

## Renommer le site Netlify

Pour changer l'adresse Netlify :

1. ouvrir le projet dans Netlify,
2. aller dans `Site configuration`,
3. ouvrir `General`,
4. chercher `Site details`,
5. cliquer sur `Change site name`.

Tu pourras remplacer l'adresse par un nom plus propre du type :
`planning-nemaucar.netlify.app`

## Ajouter un nom de domaine

Pour utiliser ton propre domaine :

1. dans Netlify, ouvrir `Domain management`,
2. cliquer sur `Add a domain`,
3. saisir ton domaine,
4. suivre les indications DNS affichees par Netlify.

Exemples :

- `planning.nemaucar.com`
- `location.nemaucar.com`

## Local

Si tu ouvres simplement `index.html` hors Netlify, l'application peut encore fonctionner en mode local de secours.

Pour la vraie utilisation quotidienne, utilise la version Netlify.
